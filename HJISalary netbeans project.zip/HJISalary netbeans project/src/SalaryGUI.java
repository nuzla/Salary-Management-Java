
import java.text.DecimalFormat;
//mport javax.swing.JFrame;
import javax.swing.JOptionPane;
//import javax.swing.JPanel;

public class SalaryGUI extends javax.swing.JFrame {
   public static Double rmti,rmto,rtti,rtto,rwti,rwto,rthti,rthto,rfti,rfto;
   public static boolean chkm,chkt,chkw,chkth,chkf,chkabm,chkabt,chkabw,chkabth,chkabf;
   public static String empcodeno;
   public static int emplevel;
   
    public SalaryGUI() {
        initComponents();
    }


    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jtxtEmpCode = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        jcmbLevel = new javax.swing.JComboBox();
        jLabel3 = new javax.swing.JLabel();
        jLayeredPane1 = new javax.swing.JLayeredPane();
        jLabel6 = new javax.swing.JLabel();
        jspnRMIM = new javax.swing.JSpinner();
        jLabel5 = new javax.swing.JLabel();
        jspnRMIH = new javax.swing.JSpinner();
        jLabel4 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jspnRTIH = new javax.swing.JSpinner();
        jspnRTIM = new javax.swing.JSpinner();
        jspnRWIM = new javax.swing.JSpinner();
        jspnRWIH = new javax.swing.JSpinner();
        jLabel8 = new javax.swing.JLabel();
        jspnRThIH = new javax.swing.JSpinner();
        jLabel9 = new javax.swing.JLabel();
        jspnRThIM = new javax.swing.JSpinner();
        jspnRFIM = new javax.swing.JSpinner();
        jspnRFIH = new javax.swing.JSpinner();
        jLabel10 = new javax.swing.JLabel();
        jLabel11 = new javax.swing.JLabel();
        jchk4 = new javax.swing.JCheckBox();
        jchk0 = new javax.swing.JCheckBox();
        jchk1 = new javax.swing.JCheckBox();
        jchk2 = new javax.swing.JCheckBox();
        jchk3 = new javax.swing.JCheckBox();
        jLabel12 = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jspnRMOM = new javax.swing.JSpinner();
        jspnRMOH = new javax.swing.JSpinner();
        jspnRTOH = new javax.swing.JSpinner();
        jspnRTOM = new javax.swing.JSpinner();
        jspnRWOH = new javax.swing.JSpinner();
        jspnRWOM = new javax.swing.JSpinner();
        jspnRThOH = new javax.swing.JSpinner();
        jspnRThOM = new javax.swing.JSpinner();
        jspnRFOH = new javax.swing.JSpinner();
        jspnRFOM = new javax.swing.JSpinner();
        jLabel14 = new javax.swing.JLabel();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        jchkab4 = new javax.swing.JCheckBox();
        jchkab0 = new javax.swing.JCheckBox();
        jchkab1 = new javax.swing.JCheckBox();
        jchkab2 = new javax.swing.JCheckBox();
        jchkab3 = new javax.swing.JCheckBox();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        jbtnCalculate = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JSeparator();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("HJI Salary Calculator");
        setModalExclusionType(java.awt.Dialog.ModalExclusionType.APPLICATION_EXCLUDE);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });

        jLabel1.setText("Employee Code");

        jtxtEmpCode.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jtxtEmpCodeActionPerformed(evt);
            }
        });

        jLabel2.setText("Employee Level");

        jcmbLevel.setModel(new javax.swing.DefaultComboBoxModel(new String[] { "Select", "Level I", "Level II", "Level III" }));
        jcmbLevel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jcmbLevelActionPerformed(evt);
            }
        });

        jLabel3.setText("Regular Time");

        jLabel6.setText("Holiday");
        jLabel6.setBounds(300, 0, 50, 14);
        jLayeredPane1.add(jLabel6, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jspnRMIM.setModel(new javax.swing.SpinnerNumberModel(0, 0, 60, 1));
        jspnRMIM.setBounds(100, 20, 41, 20);
        jLayeredPane1.add(jspnRMIM, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel5.setText("Hour");
        jLabel5.setBounds(60, 0, 23, 14);
        jLayeredPane1.add(jLabel5, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jspnRMIH.setModel(new javax.swing.SpinnerNumberModel(8, 1, 17, 1));
        jspnRMIH.setBounds(50, 20, 43, 20);
        jLayeredPane1.add(jspnRMIH, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel4.setText("Mon");
        jLabel4.setBounds(20, 20, 20, 14);
        jLayeredPane1.add(jLabel4, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel7.setText("Tue");
        jLabel7.setBounds(20, 50, 18, 14);
        jLayeredPane1.add(jLabel7, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jspnRTIH.setModel(new javax.swing.SpinnerNumberModel(8, 1, 17, 1));
        jspnRTIH.setBounds(50, 50, 43, 20);
        jLayeredPane1.add(jspnRTIH, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jspnRTIM.setModel(new javax.swing.SpinnerNumberModel(0, 0, 60, 1));
        jspnRTIM.setBounds(100, 50, 41, 20);
        jLayeredPane1.add(jspnRTIM, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jspnRWIM.setModel(new javax.swing.SpinnerNumberModel(0, 0, 60, 1));
        jspnRWIM.setBounds(100, 80, 41, 20);
        jLayeredPane1.add(jspnRWIM, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jspnRWIH.setModel(new javax.swing.SpinnerNumberModel(8, 1, 17, 1));
        jspnRWIH.setBounds(50, 80, 43, 20);
        jLayeredPane1.add(jspnRWIH, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel8.setText("Wed");
        jLabel8.setBounds(20, 80, 30, 14);
        jLayeredPane1.add(jLabel8, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jspnRThIH.setModel(new javax.swing.SpinnerNumberModel(8, 1, 17, 1));
        jspnRThIH.setBounds(50, 110, 43, 20);
        jLayeredPane1.add(jspnRThIH, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel9.setText("Thu");
        jLabel9.setBounds(20, 110, 18, 14);
        jLayeredPane1.add(jLabel9, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jspnRThIM.setModel(new javax.swing.SpinnerNumberModel(0, 0, 60, 1));
        jspnRThIM.setBounds(100, 110, 41, 20);
        jLayeredPane1.add(jspnRThIM, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jspnRFIM.setModel(new javax.swing.SpinnerNumberModel(0, 0, 60, 1));
        jspnRFIM.setBounds(100, 140, 41, 20);
        jLayeredPane1.add(jspnRFIM, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jspnRFIH.setModel(new javax.swing.SpinnerNumberModel(8, 1, 17, 1));
        jspnRFIH.setBounds(50, 140, 43, 20);
        jLayeredPane1.add(jspnRFIH, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel10.setText("Fri");
        jLabel10.setBounds(20, 140, 12, 14);
        jLayeredPane1.add(jLabel10, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel11.setText("Minute");
        jLabel11.setBounds(100, 0, 32, 14);
        jLayeredPane1.add(jLabel11, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jchk4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jchk4ActionPerformed(evt);
            }
        });
        jchk4.setBounds(310, 140, 20, 21);
        jLayeredPane1.add(jchk4, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jchk0.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jchk0ActionPerformed(evt);
            }
        });
        jchk0.setBounds(310, 20, 20, 21);
        jLayeredPane1.add(jchk0, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jchk1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jchk1ActionPerformed(evt);
            }
        });
        jchk1.setBounds(310, 50, 20, 21);
        jLayeredPane1.add(jchk1, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jchk2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jchk2ActionPerformed(evt);
            }
        });
        jchk2.setBounds(310, 80, 20, 21);
        jLayeredPane1.add(jchk2, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jchk3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jchk3ActionPerformed(evt);
            }
        });
        jchk3.setBounds(310, 110, 20, 21);
        jLayeredPane1.add(jchk3, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel12.setText("Hour");
        jLabel12.setBounds(190, 0, 23, 14);
        jLayeredPane1.add(jLabel12, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel13.setText("Minute");
        jLabel13.setBounds(230, 0, 32, 14);
        jLayeredPane1.add(jLabel13, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jspnRMOM.setModel(new javax.swing.SpinnerNumberModel(0, 0, 60, 1));
        jspnRMOM.setBounds(230, 20, 41, 20);
        jLayeredPane1.add(jspnRMOM, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jspnRMOH.setModel(new javax.swing.SpinnerNumberModel(17, 8, 24, 1));
        jspnRMOH.setBounds(180, 20, 43, 20);
        jLayeredPane1.add(jspnRMOH, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jspnRTOH.setModel(new javax.swing.SpinnerNumberModel(17, 8, 24, 1));
        jspnRTOH.setBounds(180, 50, 43, 20);
        jLayeredPane1.add(jspnRTOH, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jspnRTOM.setModel(new javax.swing.SpinnerNumberModel(0, 0, 60, 1));
        jspnRTOM.setBounds(230, 50, 41, 20);
        jLayeredPane1.add(jspnRTOM, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jspnRWOH.setModel(new javax.swing.SpinnerNumberModel(17, 8, 24, 1));
        jspnRWOH.setBounds(180, 80, 43, 20);
        jLayeredPane1.add(jspnRWOH, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jspnRWOM.setModel(new javax.swing.SpinnerNumberModel(0, 0, 60, 1));
        jspnRWOM.setBounds(230, 80, 41, 20);
        jLayeredPane1.add(jspnRWOM, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jspnRThOH.setModel(new javax.swing.SpinnerNumberModel(17, 8, 24, 1));
        jspnRThOH.setBounds(180, 110, 43, 20);
        jLayeredPane1.add(jspnRThOH, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jspnRThOM.setModel(new javax.swing.SpinnerNumberModel(0, 0, 60, 1));
        jspnRThOM.setBounds(230, 110, 41, 20);
        jLayeredPane1.add(jspnRThOM, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jspnRFOH.setModel(new javax.swing.SpinnerNumberModel(17, 8, 24, 1));
        jspnRFOH.setBounds(180, 140, 43, 20);
        jLayeredPane1.add(jspnRFOH, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jspnRFOM.setModel(new javax.swing.SpinnerNumberModel(0, 0, 60, 1));
        jspnRFOM.setBounds(230, 140, 41, 20);
        jLayeredPane1.add(jspnRFOM, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel14.setText("-");
        jLabel14.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jLabel14.setBounds(160, 140, 20, 14);
        jLayeredPane1.add(jLabel14, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel15.setText("-");
        jLabel15.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jLabel15.setBounds(160, 20, 20, 14);
        jLayeredPane1.add(jLabel15, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel16.setText("-");
        jLabel16.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jLabel16.setBounds(160, 50, 20, 14);
        jLayeredPane1.add(jLabel16, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel17.setText("-");
        jLabel17.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jLabel17.setBounds(160, 80, 20, 14);
        jLayeredPane1.add(jLabel17, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel18.setText("-");
        jLabel18.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        jLabel18.setBounds(160, 110, 20, 14);
        jLayeredPane1.add(jLabel18, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel21.setText("Absent");
        jLabel21.setBounds(360, 0, 34, 14);
        jLayeredPane1.add(jLabel21, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jchkab4.setBounds(360, 140, 20, 21);
        jLayeredPane1.add(jchkab4, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jchkab0.setBounds(360, 20, 20, 21);
        jLayeredPane1.add(jchkab0, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jchkab1.setBounds(360, 50, 20, 21);
        jLayeredPane1.add(jchkab1, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jchkab2.setBounds(360, 80, 20, 21);
        jLayeredPane1.add(jchkab2, javax.swing.JLayeredPane.DEFAULT_LAYER);
        jchkab3.setBounds(360, 110, 20, 21);
        jLayeredPane1.add(jchkab3, javax.swing.JLayeredPane.DEFAULT_LAYER);

        jLabel19.setText("In");

        jLabel20.setText("Out");

        jbtnCalculate.setText("Calculate Salary");
        jbtnCalculate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnCalculateActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addGap(72, 72, 72)
                .addComponent(jLabel19)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel20)
                .addGap(132, 132, 132))
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLayeredPane1)
                .addContainerGap())
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jSeparator1)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jbtnCalculate)
                .addGap(141, 141, 141))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel1)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jtxtEmpCode, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel2)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(jcmbLevel, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(133, 133, 133)
                        .addComponent(jLabel3)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(jtxtEmpCode, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(jcmbLevel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(10, 10, 10)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel20)
                    .addComponent(jLabel19))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLayeredPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 170, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jbtnCalculate)
                .addGap(18, 18, 18))
        );

        setSize(new java.awt.Dimension(422, 394));
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
    
}//GEN-LAST:event_formWindowOpened

private void jchk4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jchk4ActionPerformed
// TODO add your handling code here:
}//GEN-LAST:event_jchk4ActionPerformed

private void jchk0ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jchk0ActionPerformed
// TODO add your handling code here:
}//GEN-LAST:event_jchk0ActionPerformed

private void jchk1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jchk1ActionPerformed
// TODO add your handling code here:
}//GEN-LAST:event_jchk1ActionPerformed

private void jchk2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jchk2ActionPerformed
// TODO add your handling code here:
}//GEN-LAST:event_jchk2ActionPerformed

private void jchk3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jchk3ActionPerformed
// TODO add your handling code here:
}//GEN-LAST:event_jchk3ActionPerformed

private void jbtnCalculateActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jbtnCalculateActionPerformed
    
    
    
        rmti=Double.parseDouble(jspnRMIH.getValue().toString())+Double.parseDouble(jspnRMIM.getValue().toString())/60;
        rtti=Double.parseDouble(jspnRTIH.getValue().toString())+Double.parseDouble(jspnRTIM.getValue().toString())/60;
        rwti=Double.parseDouble(jspnRWIH.getValue().toString())+Double.parseDouble(jspnRWIM.getValue().toString())/60;
        rthti=Double.parseDouble(jspnRThIH.getValue().toString())+Double.parseDouble(jspnRThIM.getValue().toString())/60;
        rfti=Double.parseDouble(jspnRFIH.getValue().toString())+Double.parseDouble(jspnRFIM.getValue().toString())/60;

        rmto=Double.parseDouble(jspnRMOH.getValue().toString())+Double.parseDouble(jspnRMOM.getValue().toString())/60;
        rtto=Double.parseDouble(jspnRTOH.getValue().toString())+Double.parseDouble(jspnRTOM.getValue().toString())/60;
        rwto=Double.parseDouble(jspnRWOH.getValue().toString())+Double.parseDouble(jspnRWOM.getValue().toString())/60;
        rthto=Double.parseDouble(jspnRThOH.getValue().toString())+Double.parseDouble(jspnRThOM.getValue().toString())/60;
        rfto=Double.parseDouble(jspnRFOH.getValue().toString())+Double.parseDouble(jspnRFOM.getValue().toString())/60;

        chkm=jchk0.isSelected();
        chkt=jchk1.isSelected();
        chkw=jchk2.isSelected();
        chkth=jchk3.isSelected();
        chkf=jchk4.isSelected();
        
        chkabm=jchkab0.isSelected();
        chkabt=jchkab1.isSelected();
        chkabw=jchkab2.isSelected();
        chkabth=jchkab3.isSelected();
        chkabf=jchkab4.isSelected();
        
       // JOptionPane.showMessageDialog(null,"Absent monday check box checked - "+chkabm);
        
        emplevel=jcmbLevel.getSelectedIndex();
        empcodeno=jtxtEmpCode.getText();
        
        
        //Employee em =new Employee();
       
        //System.gc();
   
    switch(emplevel){
        case 1:     //Level I
                    EmpLevel1 emp1=new EmpLevel1();
                    emp1.calculateSalary();
                    emp1.display();
                    break;
        case 2:     //Level II
                    EmpLevel2 emp2=new EmpLevel2();
                    emp2.calculateSalary();
                    emp2.display();
                    break;

        case 3:     //Level III
                    EmpLevel3 emp3=new EmpLevel3();
                    emp3.calculateSalary();
                    emp3.display();
                    break;
        default:
                    JOptionPane.showMessageDialog(null,"Invalid Selection of Level. \n Please Select the level" );
    }
    
    //jtxtEmpCode.setText(new Double(rmon).toString());
   
}//GEN-LAST:event_jbtnCalculateActionPerformed

private void jtxtEmpCodeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jtxtEmpCodeActionPerformed

}//GEN-LAST:event_jtxtEmpCodeActionPerformed

    private void jcmbLevelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jcmbLevelActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jcmbLevelActionPerformed


    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Windows".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(SalaryGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(SalaryGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(SalaryGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(SalaryGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {

            @Override
       public void run() {
                new SalaryGUI().setVisible(true);
            }
        });
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JLayeredPane jLayeredPane1;
    private javax.swing.JSeparator jSeparator1;
    public javax.swing.JButton jbtnCalculate;
    public javax.swing.JCheckBox jchk0;
    public javax.swing.JCheckBox jchk1;
    public javax.swing.JCheckBox jchk2;
    public javax.swing.JCheckBox jchk3;
    public javax.swing.JCheckBox jchk4;
    public javax.swing.JCheckBox jchkab0;
    public javax.swing.JCheckBox jchkab1;
    public javax.swing.JCheckBox jchkab2;
    public javax.swing.JCheckBox jchkab3;
    public javax.swing.JCheckBox jchkab4;
    public javax.swing.JComboBox jcmbLevel;
    public javax.swing.JSpinner jspnRFIH;
    public javax.swing.JSpinner jspnRFIM;
    public javax.swing.JSpinner jspnRFOH;
    public javax.swing.JSpinner jspnRFOM;
    public javax.swing.JSpinner jspnRMIH;
    public javax.swing.JSpinner jspnRMIM;
    public javax.swing.JSpinner jspnRMOH;
    public javax.swing.JSpinner jspnRMOM;
    public javax.swing.JSpinner jspnRTIH;
    public javax.swing.JSpinner jspnRTIM;
    public javax.swing.JSpinner jspnRTOH;
    public javax.swing.JSpinner jspnRTOM;
    public javax.swing.JSpinner jspnRThIH;
    public javax.swing.JSpinner jspnRThIM;
    public javax.swing.JSpinner jspnRThOH;
    public javax.swing.JSpinner jspnRThOM;
    public javax.swing.JSpinner jspnRWIH;
    public javax.swing.JSpinner jspnRWIM;
    public javax.swing.JSpinner jspnRWOH;
    public javax.swing.JSpinner jspnRWOM;
    public javax.swing.JTextField jtxtEmpCode;
    // End of variables declaration//GEN-END:variables
}




class Employee extends SalaryGUI{
    
    
    public Double basicLevel1=1000.0,basicLevel2=750.0,basicLevel3=500.0;
    public Double tax=0.1,gsisLevel1=0.01,gsisLevel2=0.015,gsisLevel3=0.02,allowance=200.0;
    public Double holiday=0.0,regular=0.0,overtime=0.0,time=0.0,ot=0.0;
    public Double taxdeduction=0.0,gsisdeduction=0.0, wgsi=0.0,netsalary=0.0;
    public Double[] time_in=new Double[5];
    public Double[] time_out=new Double[5];
    public boolean[] chkholiday=new boolean[5];
    public boolean[] chkab=new boolean[5];
    public int level,totalhours=0;
    public static String empcode,displaymsg;
    public DecimalFormat df=new DecimalFormat("#.##");
    
    
    Employee(){
       
        time_in[0]=rmti;
        time_in[1]=rtti;
        time_in[2]=rwti;
        time_in[3]=rthti;
        time_in[4]=rfti;

        time_out[0]=rmto;
        time_out[1]=rtto;
        time_out[2]=rwto;
        time_out[3]=rthto;
        time_out[4]=rfto;

        chkholiday[0]=chkm;
        chkholiday[1]=chkt;
        chkholiday[2]=chkw;
        chkholiday[3]=chkth;
        chkholiday[4]=chkf;
        
        chkab[0]=chkabm;
        chkab[1]=chkabt;
        chkab[2]=chkabw;
        chkab[3]=chkabth;
        chkab[4]=chkabf;
        
        level=emplevel;       
        
        empcode=empcodeno;
        // JOptionPane.showMessageDialog(null,"Absent monday check box checked in Employee class - "+chkab[0]);
        
    }
    
    void calculateSalary(){     
        JOptionPane.showMessageDialog(null,"employee  working "); 
        
    }     
     
    void salary(Double basicLevel,Double gsisLevel){     

        for(int i=0;i<5;i++){
            
            if(chkab[i]==false){ 
                if(time_in[i]<8.0){
                 time_in[i]=8.0;  
                }
                totalhours+=time_out[i]-time_in[i];
                
                if(chkholiday[i]){
                    time=time_out[i]-time_in[i];
                    holiday+=(basicLevel/8.0)*1.1*time;
                }
                else if(time_out[i]<=17.0){
                    time=time_out[i]-time_in[i];
                    regular+=(basicLevel/8.0)*time;
                }
                else if(time_out[i]>17.5){
                    time=9.0;
                    regular+=(basicLevel/8.0)*time;
                    if(time_out[i]>=20.5){
                        ot=3.0;                
                        overtime+=(basicLevel/8.0)*1.1*ot;
                    }
                    else{
                        ot=time_out[i]-17.5;                
                        overtime+=(basicLevel/8.0)*1.1*ot;
                    }
                }
                else{
                    time=9.0;
                    regular+=(basicLevel/8.0)*time;
                } 
            } 
        }
        
        wgsi=holiday+regular+overtime;
        taxdeduction=wgsi*tax;
        gsisdeduction=basicLevel*gsisLevel;        
        netsalary=(wgsi-(taxdeduction+gsisdeduction))+allowance;
    }     
     
    
    
    void display(){

        displaymsg="Total hours worked \t : "+totalhours
                    +"\nRegular Income \t\t : "+df.format(regular).toString()
                    +"\nHoliday Income \t\t : "+df.format(holiday).toString()
                    +"\nOvertime Income \t : "+df.format(overtime).toString()
                    +"\nGross Income \t \t : "+df.format(wgsi).toString()
                    +"\nNet Income \t \t : "+df.format(netsalary).toString();
        
        salaryview slview =new salaryview(); 
        salaryview.jlblempcode.setText("Employee Code : "+empcode);
        salaryview.jlblEmpLevel.setText("Employee Level : "+level);
        salaryview.jTextAreaDisplay.setText(displaymsg);
        slview.setVisible(true);
    }
}

class EmpLevel1 extends Employee{    
    
    EmpLevel1(){
        super();
    }
      
    @Override
    void calculateSalary(){
        super.salary(basicLevel1, gsisLevel1);
    }
    
    @Override
    void display(){
       super.display();        
    }
}

class EmpLevel2 extends Employee{
    
   EmpLevel2(){
        super();
    }
      
    @Override
    void calculateSalary(){
        super.salary(basicLevel2, gsisLevel2);
    }
    
    @Override
    void display(){
       super.display();        
    }
}

class EmpLevel3 extends Employee{
    EmpLevel3(){
        super();
    }
      
    @Override
    void calculateSalary(){
        super.salary(basicLevel3, gsisLevel3);
    }
    
    @Override
    void display(){
       super.display();        
    }
}